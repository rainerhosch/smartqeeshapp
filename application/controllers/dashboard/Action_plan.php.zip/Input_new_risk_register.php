<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *  File Name             : Home.php
 *  File Type             : Controller
 *  File Package          : CI_Controller
 ** * * * * * * * * * * * * * * * * * **
 *  Author                : Rizky Ardiansyah
 *  Date Created          : 29/01/2022
 *  Quots of the code     : 'rapihkan lah code mu, seperti halnya kau menata kehidupan'
 */
 
class Input_new_risk_register extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        login_check();
        $this->load->model('M_risk_register', 'risk');
    }


    public function index()
    {
        
        $risk_category = $this->risk->risk_category()->result_array();
        $risk_condition = $this->risk->risk_condition()->result_array();
        $risk_status = $this->risk->risk_status()->result_array();
        $risk_type = $this->risk->risk_type()->result_array();
        $user = $this->risk->user()->result_array();
        $dataRisk = $this->risk->dataRisk()->result_array();
        // echo '<pre>';
        // echo print_r($risk_type);
        // echo '</pre>';
        // exit();
        
        $data['risk_category'] = $risk_category;
        $data['risk_condition'] = $risk_condition;
        $data['risk_status'] = $risk_status;
        $data['risk_type'] = $risk_type;
        $data['user'] = $user;
        $data['dataRisk'] = $dataRisk;
        
        $data['title'] = 'Smart Qeesh App';
        $data['page'] = 'Home';
        $data['subpage'] = 'Blank Page';
        // $data['user_divisi'] = 'CT-HSE';
        $data['content'] = 'pages/risk_management/input_risk_register';
        $this->load->view('template', $data);
        
    }
    
    public function action_input_new_risk_register()
    {
        
        $activity = $this->input->post('activity');
        $tahapan = $this->input->post('tahapan_proses');
        $risk_source_id = $this->input->post('risk_source');
        $risk_context = $this->input->post('risk_context');
        $risk_analysis = $this->input->post('risk_analysis');
        $risk_type = $this->input->post('risk_type');
        $risk_category = $this->input->post('risk_category');
        $risk_condition = $this->input->post('risk_condition');
        $risk_treatment = $this->input->post('risk_treatment');
        $consequences = $this->input->post('consequences');
        $risk_level = $this->input->post('risk_level');
        $likelihood = $this->input->post('likehood');
        $risk_status = $this->input->post('risk_status');
        $risk_owner = $this->input->post('risk_owner');
        $id_user = $this->session->user_id;
        
        $data = [
            'activity' => $activity,
            'tahapan' => $tahapan,
            'risk_source_id' => $risk_source_id,
            'risk_context' => $risk_context,
            'risk_analysis' => $risk_analysis,
            'risk_type' => $risk_type,
            'risk_category' => $risk_category,
            'risk_condition' => $risk_condition,
            'risk_treatment' => $risk_treatment,
            'consequences' => $consequences,
            'likelihood' => $likelihood,
            'risk_level' => $risk_level,
            'risk_status' => $risk_status,
            'risk_owner' => $risk_owner,
            'id_user' => $id_user,
            ];
        $tbl = 'risk_management';
        $save = $this->risk->insert_data($tbl, $data);
        echo '<pre>';
        echo print_r($save);
        echo '</pre>';
        exit();
    }
}
