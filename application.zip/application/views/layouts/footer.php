<footer class="main-footer text-sm">
    Copyright &copy; <strong>CT-HSE PT.Asia Pacific Fibers Tbk.Unit Karawang</strong>
</footer>
<aside class="control-sidebar control-sidebar-dark">
</aside>